<?php

namespace App\Http\Controllers;

use App\Models\Comment as ModelsComment;
use App\Models\Post;
use Dom\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{


    /**
     * Display a listing of the resource.
     */
    public function index(Post $post)
    {
        return $post->comments()->paginate(20);
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'post_id' => 'required|integer|exists:posts,id',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'description' => 'required|string',
        ]);

        $comment = ModelsComment::create([
            'post_id' => $request->post_id,
            'name' => $request->name,
            'email' => $request->email,
            'description' => $request->description,
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(ModelsComment $comment)
    {
        return $comment;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ModelsComment $comment)
    {
        $request->validate([
            'description' => 'required|string',
        ]);

        $comment->update([
            'description' => $request->description,
        ]);

        return $comment;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ModelsComment $comment)
    {
        $comment->delete();
    }
}
